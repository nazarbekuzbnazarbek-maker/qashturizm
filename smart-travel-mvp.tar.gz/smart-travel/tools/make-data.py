import json,re,sys,os
if os.path.exists("data/places.json") and "--force" not in sys.argv:
    sys.exit("data/places.json mavjud. Admin o'zgarishlari o'chib ketmasligi uchun --force kerak.")
def dms(s):
    m=re.match(r"(\d+)°(\d+)'([\d.]+)\"?[NE]?",s.strip()); d,mi,se=m.groups()
    return round(int(d)+int(mi)/60+float(se)/3600,6)
def C(a,b): return [dms(a),dms(b)]
# (slug, nom, tuman, davr, tavsif, koordinata)
Q=[
("abu-ubayda-ibn-jarroh","Abu Ubayda ibn al-Jarroh ziyoratgohi","Qarshi shahri","Sahoba","Payg'ambarimizning sahobasi, islomni dastlab qabul qilganlardan biri xotirasiga bag'ishlangan ziyoratgoh. Jayxon ko'chasida joylashgan.",C("38°52'35.29\"","65°49'0.49\"")),
("odina-masjidi","Odina masjidi","Qarshi shahri","Shayboniylar davri","Qarshidagi Odina majmuasining bir qismi, Abdullaxon madrasasi qarshisida joylashgan.",C("38°52'3.74\"","65°48'12.06\"")),
("qarshi-kokgumbaz","Ko'kgumbaz masjidi (Qarshi)","Qarshi shahri","1590–1591-yillar","Abdullaxon II davrida qurilgan jome masjidi.",C("38°51'49.53\"","65°47'29.40\"")),
("imom-moyin-nasafiy","Imom Mo'yin an-Nasafiy majmuasi","Qarshi tumani","—","Nasaf (Qarshi) da tug'ilgan hanafiy faqih xotirasiga bag'ishlangan majmua. Qovchin qishlog'ida.",C("38°46'31.08\"","65°31'45.94\"")),
("shayx-shibliy","Shayx Shibliy ziyoratgohi","Qarshi tumani","—","Mansur al-Hallojning zamondoshi bo'lgan shayx xotirasiga bag'ishlangan ziyoratgoh.",[38.790585,65.811369]),
("sulton-mir-haydar","Sulton Mir Haydar majmuasi","Kasbi tumani","—","Uch gumbazli maqbara, minora, masjidlar va ikkita sardobadan iborat majmua.",C("38°57'2.17\"","65°23'20.53\"")),
("miri-janda-ota","Miri Janda ota maqbarasi","G'uzor tumani","—","Shahobiddin Umar Suhravardiy ziyoratgohi. Mardtepa qishlog'ida.",C("38°36'24.49\"","66°15'10.08\"")),
("langar-ota-maqbarasi","Langar ota maqbarasi","Qamashi tumani","1520-yillar","Ko'kbo'loq mahallasidagi XVI asr me'moriy yodgorligi. Unda Shayx Muhammad Sodiq kabi bir qancha mashhur shayxlar dafn etilgan.",C("38°40'53.03\"","66°45'27.08\"")),
("langar-ota-masjidi","Langar ota masjidi","Qamashi tumani","1448-yil","Rivoyatga ko'ra, 1448-yilda Abul Hasan shayx tashabbusi bilan xalq hashari orqali qurilgan. Katta Langar Qur'oni shu yerda saqlanadi.",C("38°40'59.49\"","66°45'36.41\"")),
("oglonjon-ota","O'g'lonjon ota maqbarasi","Qamashi tumani","XVI asr","Pastol qishlog'idagi gumbazli maqbara.",C("38°48'38.43\"","66°35'22.20\"")),
("muborak-marvaziy","Muborak Marvaziy maqbarasi","Muborak tumani","—","Abdulloh ibn al-Muborak xotirasiga qurilgan ramziy maqbara. Sariq qishlog'ida.",C("39°11'21.03\"","65°14'43.90\"")),
("isoq-ota","Isoq ota maqbarasi","Mirishkor tumani","XIV asr","Pomuq mahallasida joylashgan qadimiy maqbara.",C("39°1'43.59\"","65°5'2.09\"")),
("shamsiddin-kulol","Shayx Shamsiddin Kulol maqbarasi","Shahrisabz shahri","XIV–XV asrlar","Dorut Tilovat majmuasining bir qismi.",C("39°2'58.68\"","66°49'40.04\"")),
("shahrisabz-kokgumbaz","Ko'k gumbaz masjidi (Shahrisabz)","Shahrisabz shahri","1435-yil","Mirzo Ulug'bek tomonidan qurilgan, Dorut Tilovat majmuasida.",C("39°2'59.30\"","66°49'38.25\"")),
("gumbazi-sayyidon","Gumbazi Sayyidon maqbarasi","Shahrisabz shahri","1437-yil","Mirzo Ulug'bek qurdirgan maqbara, Dorut Tilovat majmuasida.",C("39°2'58.42\"","66°49'39.92\"")),
("hazrati-imom","Hazrati Imom masjidi","Shahrisabz shahri","XIV–XV asrlar","Jahongir Mirzo maqbarasi yonidagi Dorus Saodat majmuasida joylashgan masjid.",C("39°3'0.20\"","66°49'47.34\"")),
("jahongir-mirzo","Jahongir Mirzo maqbarasi","Shahrisabz shahri","XIV–XV asrlar","Dorus Saodat majmuasining bir qismi.",C("39°2'59.58\"","66°49'47.49\"")),
("turk-tugyon","Turk Tug'yon ziyoratgohi","Shahrisabz tumani","—","G'elon qishlog'ida, xitoy shahzodasining qabri bilan bog'liq rivoyat mavjud.",C("39°3'24.35\"","67°27'29.58\"")),
("nishon-ota","Nishon ota ziyoratgohi","Shahrisabz tumani","—","Xo'ja Hasan Charxi Parroniy nomi bilan bog'liq. Xisor mahallasi, Xummon.",C("38°53'3.00\"","67°11'4.00\"")),
("saad-ibn-abu-vaqqos","Saad ibn Abu Vaqqos ziyoratgohi","Shahrisabz tumani","—","Bog'ishamol mahallasida joylashgan ziyoratgoh.",C("39°5'6.68\"","66°54'35.14\"")),
("xojailgor","Xo'jailg'or maqbarasi","Yakkabog' tumani","—","Sovuqbuloq mahallasidagi tepalikda joylashgan katta qabriston va maqbara.",C("38°59'47.17\"","66°41'10.69\"")),
("tezob-ota","Tezob ota maqbarasi","Yakkabog' tumani","XVI asr","Sovuqbuloq mahallasida, yonida XVI–XVII asrga oid masjid ham bor.",C("39°2'27.06\"","66°40'24.19\"")),
("tutak-ota","Tutak ota (Shodi Shayx Valiy) ziyoratgohi","Yakkabog' tumani","—","Qadimiy tut daraxtlari va buloq bor. Ishkent mahallasida.",C("38°49'19.30\"","66°56'8.67\"")),
("xoja-abdullo-ansoriy","Xo'ja Abdullo Ansoriy ziyoratgohi","Yakkabog' tumani","—","Qurashayx qishlog'ida, 2021-yilda ta'mirlangan.",C("38°52'49.08\"","66°56'59.54\"")),
("chillabuloq","Chillabuloq ziyoratgohi","Yakkabog' tumani","—","O'g'in qishlog'ida, shifobaxsh buloqlari bilan tanilgan.",C("38°47'19.60\"","66°49'33.12\"")),
("hazrati-bashir","Hazrati Bashir maqbarasi","Kitob tumani","—","Bashir mahallasidagi maqbara.",C("39°16'16.10\"","67°6'12.16\"")),
("xoja-ilmkon","Xo'ja Ilmkon maqbarasi","Kitob tumani","—","Mavlono Abdulboqi Xojagi Imkonagiy xotirasiga bag'ishlangan.",C("39°7'34.80\"","66°59'23.35\"")),
("hazrati-sulton","Hazrati Sulton ziyoratgohi","Kitob tumani","—","Shut qishlog'ida, O'zbekistonning eng baland cho'qqisi Hazrati Sulton yonida. Mahalliy aholi tog'ni «Ko'hi tavba» deb ham ataydi.",C("39°8'38.95\"","67°38'7.81\"")),
("sofi-navroz","So'fi Navro'z ziyoratgohi","Kitob tumani","—","Naqshbandiya tariqati vakili xotirasiga. Kuxsor mahallasida.",C("39°11'29.98\"","67°10'2.51\"")),
("eski-langar-ota","Langar ota ziyoratgohi (Eski Langar)","Chiroqchi tumani","XVI–XVIII asrlar","Ishqiya tariqati asoschilarining ikkita XVI asr maqbarasi va XVII–XVIII asr masjididan iborat majmua. Ta'mirlangan.",C("39°22'3.37\"","66°40'5.50\"")),
]
S=[("yusufbobo","Yusufbobo ziyoratgohi","Xovos tumani","2010-yilda qurilgan","Mahalliy aholi bu yerning tuprog'i bel va oyoq og'rig'iga shifo deb hisoblaydi. Maqbara 2010-yilda tadbirkor M. Nurullayev tomonidan qurilgan."),
("sher-bobo","Sher bobo ziyoratgohi","Xovos tumani","—","Ibrohim ismli kishi qal'ani dushmandan himoya qilgani va Hazrati Alining laqabi bilan bog'liq nomlanganligi aytiladi."),
("hasti-buzurgon","Hasti buzurgon ziyoratgohi","Xovos tumani","—","Mahalliy aholi Bobo Jobirni sahoba deb biladi. Uni «Bojobir» deb ham atashadi."),
("bibi-ocha","Bibi ocha ziyoratgohi","Xovos tumani","—","Bobo Jobir oilasidagi ayollar dafn etilgan joy."),
("saadu-said","Sa'du-Sa'id masjidi","Xovos tumani","2004-yilda jome masjidiga aylantirilgan","Bobo Jobir farzandlari nomi bilan atalgan. M. Sodiqov tashabbusi bilan 2004-yilda jome masjidiga aylantirilgan.")]
places=[]
for i,(s,n,d,per,desc,c) in enumerate(Q,1):
    places.append(dict(id=i,slug=s,image=None,name=n,region="qashqadaryo",district=d,category="ziyorat",period=per,desc=desc,coords=c,mapQuery=f"{n}, {d}, Qashqadaryo, Uzbekistan"))
for j,(s,n,d,per,desc) in enumerate(S,len(Q)+1):
    places.append(dict(id=j,slug=s,image=None,name=n,region="sirdaryo",district=d,category="ziyorat",period=per,desc=desc,coords=[40.2159,68.8160],coordsShared=True,mapQuery=f"{n}, Xovosobod, Sirdaryo, Uzbekistan"))
json.dump(places,open("data/places.json","w"),ensure_ascii=False,indent=1)
regions=[
 {"id":"qashqadaryo","name":"Qashqadaryo","center":[38.86,65.79],"dishes":[
  {"name":"Tandir go'sht","desc":"Tandirda pishirilgan qo'y go'shti, non bilan."},
  {"name":"Dimlama","desc":"Go'sht va sabzavotlar o'z bug'ida dimlanadi."},
  {"name":"Qo'y go'shtli osh","desc":"Dasturxonning asosiy taomi."},
  {"name":"Patir va obi non","desc":"Tandirda yopilgan yangi non, choy bilan."}]},
 {"id":"sirdaryo","name":"Sirdaryo","center":[40.48,68.78],"dishes":[
  {"name":"Osh (palov)","desc":"Mirzacho'l dehqonlari dasturxonining asosi."},
  {"name":"Mastava","desc":"Guruchli, sabzavotli iliq sho'rva."},
  {"name":"Daryo baliq taomlari","desc":"Sirdaryo bo'yida baliq qovurma va sho'rva."},
  {"name":"Norin","desc":"Yupqa xamir va go'shtdan tayyorlanadigan sovuq taom."}]}]
json.dump(regions,open("data/regions.json","w"),ensure_ascii=False,indent=1)
print(len(places))
