"""public/index.html dan bitta faylli demo yasaydi (ma'lumot ichiga joylanadi)."""
import json,re,sys
root="/home/claude/smart-travel/"
html=open(root+"public/index.html",encoding="utf8").read()
rico=open(root+"public/rico-local.js",encoding="utf8").read()
data={"places":json.load(open(root+"data/places.json",encoding="utf8")),"regions":json.load(open(root+"data/regions.json",encoding="utf8"))}
head=re.search(r"<head>(.*?)</head>",html,re.S).group(1)
head=re.sub(r"<meta charset[^>]*>\s*","",head)
head=re.sub(r"<meta name=\"viewport\"[^>]*>\s*","",head)
body=re.search(r"<body>(.*?)</body>",html,re.S).group(1)
body=body.replace('<script src="rico-local.js"></script>',"<script>"+rico+"</script>\n<script>window.__DATA="+json.dumps(data,ensure_ascii=False)+";</script>")
out=head+"\n<style>html,body{height:100%}</style>\n"+body
open(sys.argv[1],"w",encoding="utf8").write(out)
print(len(out))
