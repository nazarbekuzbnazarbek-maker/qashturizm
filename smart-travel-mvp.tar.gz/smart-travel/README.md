# Smart Travel Uzbekistan

## Lokal ishga tushirish
    npm install
    ADMIN_PASSWORD=parolingiz npm start      # http://localhost:3000
    Admin: http://localhost:3000/admin.html

## GitHub ga yuklash
    git init
    git add .
    git commit -m "Smart Travel MVP"
    git branch -M main
    git remote add origin https://github.com/<login>/smart-travel.git
    git push -u origin main

## Render ga joylash
1. render.com > New > Blueprint (render.yaml bor) yoki New > Web Service.
2. Build: `npm install`, Start: `npm start`, Health check: `/api/health`.
3. Environment: ADMIN_PASSWORD (majburiy), ANTHROPIC_API_KEY (ixtiyoriy, Rico uchun).
4. Doimiy disk: Disks > mount path `/var/data`, va DATA_DIR=/var/data.
   Disksiz (bepul reja) har qayta ishga tushganda admin qo'shgan ziyoratgoh va rasmlar yo'qoladi.

## APK
Render havolasi tayyor bo'lgach PWABuilder (pwabuilder.com) ga kiriting. Manifest va ikonlar tayyor.

## Ma'lumot
data/ ichidagi fayllar boshlang'ich nusxa. DATA_DIR berilsa, ishchi nusxa o'sha yerda saqlanadi.
tools/make-data.py faqat birinchi to'ldirish uchun (--force talab qiladi).
