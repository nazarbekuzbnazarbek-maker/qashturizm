const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const RicoLocal = require('./public/rico-local.js');

const app = express();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const RICO_MODEL = process.env.RICO_MODEL || 'claude-haiku-5-5';

// Render'da doimiy disk ulansa: DATA_DIR=/var/data ko'rsating. Rasmlar DATA_DIR/img ga yoziladi.
const SEED_DIR = path.join(__dirname, 'data');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : SEED_DIR;
const IMG_DIR = process.env.DATA_DIR ? path.join(DATA_DIR, 'img') : path.join(__dirname, 'public', 'img');
fs.mkdirSync(IMG_DIR, { recursive: true });
for (const f of ['places.json', 'regions.json']) {
  if (!fs.existsSync(path.join(DATA_DIR, f))) fs.copyFileSync(path.join(SEED_DIR, f), path.join(DATA_DIR, f));
}

// ---------- ma'lumot ombori ----------
const readJson = f => JSON.parse(fs.readFileSync(path.join(DATA_DIR, f), 'utf8'));
function writeJson(f, data) {
  const full = path.join(DATA_DIR, f), tmp = full + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 1));
  fs.renameSync(tmp, full);
}
let places = readJson('places.json');
let regions = readJson('regions.json');
const savePlaces = () => writeJson('places.json', places);
const saveRegions = () => writeJson('regions.json', regions);

// ---------- admin parol ----------
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
let generated = false;
if (!ADMIN_PASSWORD) { ADMIN_PASSWORD = crypto.randomBytes(6).toString('hex'); generated = true; }
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const sessions = new Map();           // token -> expiry
const attempts = new Map();           // ip -> {n, until}
const SESSION_MS = 12 * 3600 * 1000;

function requireAdmin(req, res, next) {
  const t = (req.headers.authorization || '').replace(/^Bearer /, '');
  const exp = sessions.get(t);
  if (!t || !exp || exp < Date.now()) { sessions.delete(t); return res.status(401).json({ error: 'Kirish talab qilinadi' }); }
  next();
}

// ---------- yordamchilar ----------
function mapLinks(p, origin) {
  const dest = p.coords ? p.coords.join(',') : p.mapQuery;
  const enc = encodeURIComponent(dest);
  let directions = `https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=${enc}`;
  if (origin && Number.isFinite(origin.lat) && Number.isFinite(origin.lng)) directions += `&origin=${origin.lat},${origin.lng}`;
  return { directions, view: `https://www.google.com/maps/search/?api=1&query=${enc}`, embed: `https://www.google.com/maps?q=${enc}&z=14&output=embed` };
}
const slugify = s => String(s).toLowerCase().replace(/[ʻʼ`’‘']/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'joy';
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const nextId = () => places.reduce((m, p) => Math.max(m, p.id), 0) + 1;

function cleanPlace(body, existing) {
  const name = str(body.name, 120);
  if (!name) return { error: 'Nomi kiritilmagan' };
  const region = str(body.region, 40);
  if (!regions.some(r => r.id === region)) return { error: 'Viloyat noto\'g\'ri' };
  let coords = null;
  const lat = body.lat === '' || body.lat == null ? null : Number(body.lat);
  const lng = body.lng === '' || body.lng == null ? null : Number(body.lng);
  if (lat !== null || lng !== null) {
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180)
      return { error: 'Koordinata noto\'g\'ri (kenglik -90..90, uzunlik -180..180)' };
    coords = [Math.round(lat * 1e6) / 1e6, Math.round(lng * 1e6) / 1e6];
  }
  const district = str(body.district, 80);
  const out = {
    ...(existing || {}),
    name, region, district,
    category: 'ziyorat',
    period: str(body.period, 80) || '—',
    desc: str(body.desc, 2000),
    coords,
    mapQuery: str(body.mapQuery, 200) || `${name}, ${district}, Uzbekistan`
  };
  delete out.coordsShared;                 // admin kiritgan koordinata aniq deb hisoblanadi
  return { place: out };
}

app.get('/api/health', (req, res) => res.json({ status: 'ok', rico: API_KEY ? 'claude' : 'local' }));

// ---------- admin API ----------
const loginParser = express.json({ limit: '2kb' });
app.post('/api/admin/login', loginParser, (req, res) => {
  const ip = req.ip, a = attempts.get(ip) || { n: 0, until: 0 };
  if (a.until > Date.now()) return res.status(429).json({ error: 'Juda ko\'p urinish. 15 daqiqadan so\'ng qayta urining.' });
  const ok = crypto.timingSafeEqual(sha(req.body.password || ''), sha(ADMIN_PASSWORD));
  if (!ok) {
    a.n += 1; if (a.n >= 5) { a.until = Date.now() + 15 * 60 * 1000; a.n = 0; }
    attempts.set(ip, a);
    return res.status(401).json({ error: 'Parol noto\'g\'ri' });
  }
  attempts.delete(ip);
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, Date.now() + SESSION_MS);
  res.json({ token });
});

// rasm yuklash: brauzer JPEG ga aylantirib yuboradi (data URL)
app.post('/api/admin/places/:id/image', requireAdmin, express.json({ limit: '8mb' }), (req, res) => {
  const p = places.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Topilmadi' });
  const m = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(req.body.dataUrl || '');
  if (!m) return res.status(400).json({ error: 'Faqat JPEG rasm qabul qilinadi' });
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length > 6 * 1024 * 1024) return res.status(413).json({ error: 'Rasm 6 MB dan oshmasin' });
  if (buf[0] !== 0xff || buf[1] !== 0xd8) return res.status(400).json({ error: 'Rasm fayli buzilgan' });
  const file = `${p.slug}-${Date.now()}.jpg`;
  fs.writeFileSync(path.join(IMG_DIR, file), buf);
  removeImage(p);
  p.image = 'img/' + file;
  savePlaces();
  res.json(p);
});

app.use(express.json({ limit: '50kb' }));

function removeImage(p) {
  if (p.image && /^img\/[\w.-]+\.jpg$/.test(p.image)) fs.promises.unlink(path.join(IMG_DIR, path.basename(p.image))).catch(() => {});
  p.image = null;
}

app.get('/api/admin/data', requireAdmin, (req, res) => res.json({ places, regions }));

app.post('/api/admin/places', requireAdmin, (req, res) => {
  const { place, error } = cleanPlace(req.body);
  if (error) return res.status(400).json({ error });
  let slug = slugify(place.name), base = slug, i = 2;
  while (places.some(p => p.slug === slug)) slug = `${base}-${i++}`;
  const created = { id: nextId(), slug, image: null, ...place };
  places.push(created);
  savePlaces();
  res.status(201).json(created);
});

app.put('/api/admin/places/:id', requireAdmin, (req, res) => {
  const idx = places.findIndex(p => p.id === Number(req.params.id));
  if (idx < 0) return res.status(404).json({ error: 'Topilmadi' });
  const { place, error } = cleanPlace(req.body, places[idx]);
  if (error) return res.status(400).json({ error });
  places[idx] = place;
  savePlaces();
  res.json(place);
});

app.delete('/api/admin/places/:id', requireAdmin, (req, res) => {
  const idx = places.findIndex(p => p.id === Number(req.params.id));
  if (idx < 0) return res.status(404).json({ error: 'Topilmadi' });
  removeImage(places[idx]);
  places.splice(idx, 1);
  savePlaces();
  res.json({ ok: true });
});

app.delete('/api/admin/places/:id/image', requireAdmin, (req, res) => {
  const p = places.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Topilmadi' });
  removeImage(p); savePlaces(); res.json(p);
});

app.put('/api/admin/regions/:id', requireAdmin, (req, res) => {
  const r = regions.find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'Topilmadi' });
  const dishes = Array.isArray(req.body.dishes) ? req.body.dishes : null;
  if (!dishes) return res.status(400).json({ error: 'Taomlar ro\'yxati kerak' });
  r.dishes = dishes.slice(0, 20).map(d => ({ name: str(d.name, 80), desc: str(d.desc, 300) })).filter(d => d.name);
  saveRegions();
  res.json(r);
});

// ---------- ochiq API ----------
app.use('/img', express.static(IMG_DIR, { maxAge: '7d' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/regions', (req, res) => res.json(regions));

app.get('/api/places', (req, res) => {
  const { region = 'all', q = '' } = req.query;
  const s = RicoLocal.norm(q);
  const data = places
    .filter(p => region === 'all' || p.region === region)
    .filter(p => !s || RicoLocal.norm(`${p.name} ${p.district} ${p.desc}`).includes(s))
    .map(p => ({ ...p, links: mapLinks(p) }));
  res.json({ count: data.length, data });
});

app.get('/api/places/:id', (req, res) => {
  const p = places.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Maskan topilmadi' });
  res.json({ ...p, links: mapLinks(p), dishes: regions.find(r => r.id === p.region)?.dishes || [] });
});

app.get('/api/places/:id/directions', (req, res) => {
  const p = places.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Maskan topilmadi' });
  res.json(mapLinks(p, { lat: parseFloat(req.query.lat), lng: parseFloat(req.query.lng) }));
});

// ---------- Rico AI ----------
const SYSTEM = () => `Sen Rico, Smart Travel Uzbekistan ilovasining sayohat yordamchisisan. Qashqadaryo va Sirdaryo ziyoratgohlari haqida o'zbek tilida, qisqa va aniq javob ber.
Faqat quyidagi bazadagi ma'lumotga tayan. Bazada yo'q faktni o'ylab topma. Bilmasang, "bazada bu haqda ma'lumot yo'q" de.
Javobda maskan nomini bazadagidek yoz. Yo'nalish so'ralsa, ilovadagi «Yo'nalish» tugmasini bosishni ayt.
Mintaqaviy taomlar: ${regions.map(r => `${r.name}: ${r.dishes.map(d => d.name).join(', ')}`).join('; ')}.
BAZA:
${places.map(p => `- ${p.name} | ${p.region} | ${p.district} | ${p.period} | ${p.desc}`).join('\n')}`;

async function askClaude(message, history) {
  const msgs = [...history.slice(-8).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content).slice(0, 1000) })), { role: 'user', content: message }];
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: RICO_MODEL, max_tokens: 600, system: SYSTEM(), messages: msgs })
  });
  if (!r.ok) throw new Error('Claude API ' + r.status);
  const j = await r.json();
  return j.content.map(c => c.text || '').join('').trim();
}

app.post('/api/rico', async (req, res) => {
  const message = String(req.body.message || '').trim().slice(0, 500);
  const history = Array.isArray(req.body.history) ? req.body.history : [];
  if (!message) return res.status(400).json({ error: 'Savol bo\'sh' });
  let reply, source = 'local';
  if (API_KEY) {
    try { reply = await askClaude(message, history); source = 'claude'; }
    catch (e) { console.error('Rico:', e.message); }
  }
  const local = RicoLocal.answer(message, places, regions);
  if (!reply) reply = local.reply;
  const mentioned = places.filter(p => RicoLocal.norm(reply).includes(RicoLocal.norm(p.name))).map(p => p.id);
  res.json({ reply, places: [...new Set([...mentioned, ...local.places])].slice(0, 3), source });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint topilmadi' }));
app.use((err, req, res, next) => res.status(err.status || 500).json({ error: err.type === 'entity.too.large' ? 'Hajm juda katta' : 'Server xatosi' }));

app.listen(PORT, () => {
  console.log(`Smart Travel: http://localhost:${PORT}  (Rico: ${API_KEY ? 'Claude API' : 'kalitsiz rejim'})`);
  console.log(`Admin panel:  http://localhost:${PORT}/admin.html`);
  if (generated) console.log(`ADMIN_PASSWORD o'rnatilmagan. Vaqtinchalik parol: ${ADMIN_PASSWORD}`);
});
