/* Rico AI: kalitsiz zaxira javob mexanizmi. Brauzerda ham, Node'da ham ishlaydi. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.RicoLocal = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const norm = s => String(s || '').toLowerCase().replace(/[ʻʼ`’‘']/g, '').replace(/\s+/g, ' ').trim();
  const has = (q, re) => re.test(q);

  function score(place, tokens) {
    const n = norm(place.name), d = norm(place.district), t = norm(place.desc), r = norm(place.region);
    let s = 0;
    for (const w of tokens) {
      const forms = [w, w.slice(0, -1), w.slice(0, -2), w.slice(0, -3), w.slice(0, -4), w.slice(0, -5)].filter(x => x.length >= Math.min(5, w.length));
      for (const k of forms) {
        if (n.includes(k)) { s += 3; break; }
        if (d.includes(k)) { s += 2; break; }
        if (r.includes(k)) { s += 1; break; }
        if (t.includes(k)) { s += 1; break; }
      }
    }
    return s;
  }

  function answer(message, places, regions) {
    const q = norm(message);
    const stop = new Set(['haqida', 'menga', 'ayt', 'qanday', 'qayerda', 'bor', 'bormoq', 'ziyoratgoh', 'ziyoratgohlar', 'maskan', 'nima', 'qaysi', 'bilan', 'uchun', 'yonalish', 'taom', 'ovqat', 'joylar', 'joy', 'yeyiladi', 'yeymiz', 'tavsiya']);
    const tokens = q.split(/[^a-z0-9а-я]+/).filter(w => w.length >= 3 && !stop.has(w));
    const wantFood = has(q, /ovqat|taom|yey|tamaddi|restoran|osh\b/);
    const wantDir = has(q, /yonalish|qanday bor|marshrut|yol|xarita|lokatsiya|manzil|navigator/);
    const wantCount = has(q, /nechta|royxat|barcha|hammasi/);

    const ranked = places.map(p => ({ p, s: score(p, tokens) })).filter(x => x.s > 0).sort((a, b) => b.s - a.s);
    const top = ranked.slice(0, 3).map(x => x.p);
    const regionHit = regions.find(r => q.includes(norm(r.name)));

    if (wantFood) {
      const regs = regionHit ? [regionHit] : top[0] ? regions.filter(r => r.id === top[0].region) : regions;
      const lines = regs.map(r => `${r.name} taomlari:\n` + r.dishes.map(d => `• ${d.name}: ${d.desc}`).join('\n'));
      return { reply: lines.join('\n\n') + '\n\nMahalliy choyxonalarda aniq menyuni so\'rab ko\'ring.', places: top.map(p => p.id) };
    }
    if (wantCount && !top.length) {
      const c = regions.map(r => `${r.name}: ${places.filter(p => p.region === r.id).length} ta`).join(', ');
      return { reply: `Bazada ${places.length} ta ziyoratgoh bor. ${c}. Qaysi tuman yoki nomni qidiramiz?`, places: [] };
    }
    if (top.length) {
      const first = top[0];
      let reply = `${first.name} (${first.district}). ${first.desc}`;
      if (first.period && first.period !== '—') reply += ` Davri: ${first.period}.`;
      if (wantDir) reply += '\n\nYo\'nalish uchun kartadagi «Yo\'nalish» tugmasini bosing. Google Maps sizni shu joyga olib boradi.';
      if (top.length > 1) reply += `\n\nYana: ${top.slice(1).map(p => p.name).join('; ')}.`;
      return { reply, places: top.map(p => p.id) };
    }
    if (regionHit) {
      const list = places.filter(p => p.region === regionHit.id).slice(0, 3);
      return { reply: `${regionHit.name} bo'yicha ${places.filter(p => p.region === regionHit.id).length} ta ziyoratgoh bor. Masalan:`, places: list.map(p => p.id) };
    }
    return { reply: 'Salom, men Rico. Ziyoratgohlar, ularning tarixi, yo\'nalishi va mahalliy taomlar haqida so\'rang. Masalan: «Langar ota haqida ayt» yoki «Shahrisabzda nima yeyiladi?»', places: [] };
  }
  return { answer, norm };
});
